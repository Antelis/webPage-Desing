// Access HTML elements

let botDoorPath = './images/robot.svg';
let beachDoorPath = './images/beach.svg';
let spaceDoorPath = './images/space.svg';
let closedDoorPath = './images/closed_door.svg';

let numClosedDoors = 3;
let openDoor1;
let openDoor2;
let openDoor3;
let currentlyPlaying = true;

// Define game logic to check doors, progress game, end game, and choose a random chore door


// Add onclick handlers to doors and start button


// Start a game round
